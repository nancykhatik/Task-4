# Task 4: Version-Controlled DevOps Project with Git

## Objective
Manage a DevOps project using Git best practices with Git and GitHub.

## Project contents
- `docs/git-workflow.md` — workflow, branching, pull requests, tags, and conflict resolution.
- `docs/interview-questions.md` — answers to the task's interview questions.
- `.gitignore` — common files and secrets that should not be committed.
- `scripts/git-workflow-demo.sh` — optional local demo commands.
- `CHANGELOG.md` — example release notes.

## Branching strategy
- `main`: stable, reviewed work.
- `dev`: integration branch for ongoing development.
- `feature/<name>`: focused changes created from `dev`, merged through a pull request.

## Quick start
```bash
git clone <YOUR_REPOSITORY_URL>
cd task4-version-controlled-devops
git checkout -b dev
```

Example feature workflow:
```bash
git checkout dev
git pull origin dev
git checkout -b feature/add-documentation
# Make and review changes
git add docs/
git commit -m "docs: add Git workflow documentation"
git push -u origin feature/add-documentation
```
Open a pull request from `feature/add-documentation` into `dev`. After validation, open a pull request from `dev` into `main`.

## Setup and publish to GitHub
See [`docs/git-workflow.md`](docs/git-workflow.md) for complete commands, including remote setup, PRs, tags, and conflict resolution.

## GitHub repository checklist
1. Create a new **public or private** GitHub repository named `task4-version-controlled-devops` (do not initialize it with a README if pushing this existing project).
2. Run the commands in `docs/git-workflow.md`.
3. Push `main`, `dev`, and a feature branch.
4. Create pull requests and merge them on GitHub. A real PR can only be created and merged in your GitHub account.
5. Create and push a release tag such as `v1.0.0`.

## Deliverables
This repository contains the documentation and commands needed to demonstrate the task. Replace `<YOUR_REPOSITORY_URL>` with your actual URL and follow the GitHub steps to publish it.
