#!/usr/bin/env bash
set -euo pipefail

# Run from the project repository after the first commit.
# This script demonstrates local branch creation only; it does not create PRs.
git switch main
git switch -c dev 2>/dev/null || git switch dev
git switch -c feature/demo-workflow 2>/dev/null || git switch feature/demo-workflow
printf 'Demo branch: %s\n' "$(git branch --show-current)"
printf 'Review branches with: git branch --all\n'
printf 'Push with: git push -u origin feature/demo-workflow\n'
printf 'Then create a PR on GitHub from feature/demo-workflow to dev.\n'
