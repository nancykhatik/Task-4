# Git Workflow and Task Execution

## 1. Initialize and configure Git
```bash
git --version
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
git init
git branch -M main
git add .
git commit -m "chore: initialize Task 4 DevOps Git project"
```
Run the configuration commands only if Git identity is not already configured.

## 2. Create `dev` and feature branches
```bash
git checkout -b dev
git push -u origin dev
git checkout -b feature/add-git-documentation
git push -u origin feature/add-git-documentation
```
Create the remote first on GitHub, then add it locally:
```bash
git remote add origin https://github.com/YOUR_USERNAME/task4-version-controlled-devops.git
git push -u origin main
```
If `origin` already exists, check it with `git remote -v`; update it using `git remote set-url origin <URL>` rather than adding it again.

## 3. Use pull requests
1. Push the feature branch.
2. On GitHub, open a pull request from `feature/add-git-documentation` into `dev`.
3. Review the diff, run checks, and merge the PR.
4. Open a second pull request from `dev` into `main`.
5. Review and merge it after confirming the project is ready.

Pull requests are created on GitHub; pushing a branch alone does not create a PR. If the repository is private, ensure collaborators have access.

## 4. Commit-message convention
Use clear, action-oriented messages. Examples:
- `docs: add Git workflow guide`
- `chore: add gitignore`
- `fix: correct branch instructions`

Suggested prefixes: `feat`, `fix`, `docs`, `test`, `refactor`, `chore`.

## 5. Tags
```bash
git checkout main
git pull origin main
git tag -a v1.0.0 -m "Task 4 initial release"
git push origin v1.0.0
git tag
```
Tags identify a particular point in repository history. Use annotated tags for releases.

## 6. Merge conflict resolution
```bash
git status
# Open each conflicted file and edit out conflict markers:
# <<<<<<<, =======, >>>>>>>
git add <resolved-file>
git commit -m "fix: resolve merge conflict"
```
For a merge conflict during a merge, test the result before committing. Abort an unfinished merge with `git merge --abort` if needed.

## 7. Stash temporary work
```bash
git stash push -m "work in progress"
git stash list
git stash pop
```
Use `git stash` to temporarily save uncommitted tracked changes while switching context. Check the result after applying a stash.

## 8. Suggested verification
```bash
git status
git branch --all
git log --oneline --graph --decorate --all
git remote -v
git tag
```

## 9. Task completion checklist
- [ ] Repository created on GitHub.
- [ ] `main`, `dev`, and at least one `feature/*` branch pushed.
- [ ] Feature PR merged into `dev`.
- [ ] `dev` PR merged into `main`.
- [ ] `.gitignore` included.
- [ ] README and Markdown documentation included.
- [ ] Annotated tag (e.g. `v1.0.0`) pushed.
- [ ] Git log and branch list verified.

> Important: The commands and files prepare the project locally. You must authenticate to GitHub and perform the remote repository creation and pull-request merges in your own account.
