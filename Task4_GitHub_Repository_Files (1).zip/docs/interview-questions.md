# Task 4 — Git Interview Questions and Answers

## 1. What is Git?
Git is a distributed version-control system that records changes to files over time. It helps developers collaborate, compare versions, and restore earlier states.

## 2. What is the difference between merge and rebase?
- **Merge** combines histories and usually creates a merge commit, preserving the branch structure.
- **Rebase** replays commits on top of another base commit, creating a more linear history with new commit IDs.
- Avoid rebasing commits that teammates are already relying on unless the team has agreed to it.

## 3. What is a pull request?
A pull request (PR) is a GitHub collaboration request to review proposed changes and merge one branch into another. It supports discussion, review, and automated checks before merging.

## 4. How do you resolve merge conflicts?
Run `git status`, open conflicted files, decide which content to keep, remove conflict markers, test the result, then run `git add <file>` and complete the merge commit. Use `git merge --abort` to cancel an unfinished merge if needed.

## 5. What are Git tags?
Tags are names attached to specific commits, often used to mark releases such as `v1.0.0`. Annotated tags include metadata and a message. Push a tag with `git push origin v1.0.0`.

## 6. What is Git workflow?
A Git workflow is the team's agreed process for creating branches, committing changes, reviewing code, merging changes, and releasing versions. This project uses `main` for stable work, `dev` for integration, and `feature/*` for individual changes.

## 7. Explain `git stash`.
`git stash` temporarily saves uncommitted changes so you can switch branches or work on another task. `git stash list` shows saved stashes; `git stash pop` reapplies the latest stash and removes it from the stash list if successful.

## 8. What is the use of `.gitignore`?
`.gitignore` tells Git which untracked files or directories to ignore, such as logs, build output, dependency folders, and local environment files. It does not automatically stop tracking a file that was already committed. Never commit passwords, tokens, or private keys.
