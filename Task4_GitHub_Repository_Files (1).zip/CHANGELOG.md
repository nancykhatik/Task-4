# Changelog

## [1.0.0] - Initial project version
- Added project README and Git workflow documentation.
- Added interview question answers.
- Added `.gitignore` and demo script.
